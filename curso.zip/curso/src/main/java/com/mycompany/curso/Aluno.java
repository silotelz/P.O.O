/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.curso;

/**
 *
 * @author alunolab13
 */
public class Aluno {
    private String nomeAluno;
    private int matricula;
    private Curso c1 = new Curso();
    
    public Aluno (){
    }
    public Aluno(String nomeAluno,int matricula){
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public Curso getC1() {
        return c1;
    }

    public void setC1(Curso c1) {
        this.c1 = c1;
    }
    
    
}
