/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.curso;
import javax.swing.JOptionPane;

/**
 *
 * @author alunolab13
 */
public class Principal {

    public static void main(String[] args){
        String codigo, nome;
        int matricula;
        String nomeAluno;
        nomeAluno = JOptionPane.showInputDialog("Digite o nome do Aluno: ");
         matricula = Integer.parseInt(JOptionPane.showInputDialog("Digite a matrícula do Aluno: "));
         codigo =   JOptionPane.showInputDialog("Digite o código do Curso: ");
         nome = JOptionPane.showInputDialog("Digite o nome do curso: ");
         JOptionPane.showMessageDialog(null,"Informações do Aluno: \n" + "Nome do aluno: " + nomeAluno +"." + "\n Matrícula do aluno" + matricula + "\n Curso: " + nome + ".");
    }
         
}
