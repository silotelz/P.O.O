/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.heranca1;

/**
 *
 * @author alunolab13
 */
public class Bebida extends Produto{
    private int quantidadeEstoque;

    public Bebida() {
    }

    public Bebida(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }
    
    
    public void darEntrada(int quantidade){
       this.quantidadeEstoque += quantidade;
    
}
    
    public void darBaixa(int quantidade){
        if (quantidade > this.quantidadeEstoque){
            System.out.println("Quantidade indisponível! Quantidade disponível: "+ this.quantidadeEstoque);
        }
        else
       this.quantidadeEstoque -= quantidade;
    }
}
