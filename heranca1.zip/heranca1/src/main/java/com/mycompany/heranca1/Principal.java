/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.heranca1;

import java.util.Arrays;

/**
 *
 * @author alunolab13
 */
public class Principal {

    public static void main(String[] args) {
        Pizza p1 = new Pizza(1,"Frango com Catupiry", 49.90, "Média", 35, Arrays.asList("Frango", "Catupiry", "Molho de tomate","Queijo"));
        Bebida b1 = new Bebida(1, "Coca-Cola", 9.90, 30);
        b1.darEntrada(40);
        b1.darBaixa(80);
    }
}
