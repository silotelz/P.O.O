/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lorenzo_02;
//import java.util.Scanner; - gera scanner para usuário inserir informações
import javax.swing.JOptionPane;
/** utiliza-se para gerar uma tela para o usuário inserir informações, ao invés
 * de gerar um scanner.
 */
/**
 *
 * @author alunolab13
 */
public class Principal {
    
    public static void main(String[] args) {
        //Scanner sc = new Scanner (System.in);
        //System.out.println("Digite a agência da conta 1");
        int agencia = Integer.parseInt(JOptionPane.showInputDialog("Digite a agência da conta 1"));
        
        //System.out.println("Digite o número da conta 1");
        int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite o número da conta 1"));
        
        //System.out.println("Digite o saldo inicial da conta 1");
        double saldo = Double.parseDouble(JOptionPane.showInputDialog("Digite o saldo inicial da conta da conta 1"));
        
        //System.out.println("Digite o limite da conta 1");
        double limite = Double.parseDouble(JOptionPane.showInputDialog("Digite o limite da conta 1"));
        
        Conta c1 = new Conta (agencia,numero,saldo,limite);
        
        //Conta c2 = new Conta (345,888,1000,800);
        int agencia2 = Integer.parseInt(JOptionPane.showInputDialog("Digite a agência da conta 2"));
        
        //System.out.println("Digite o número da conta 1");
        int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o número da conta 2"));
        
        //System.out.println("Digite o saldo inicial da conta 1");
        double saldo2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o saldo inicial da conta da conta 2"));
        
        //System.out.println("Digite o limite da conta 1");
        double limite2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o limite da conta 2"));
        //c1.transferir(c2, 10000);
        
        Conta c2 = new Conta (agencia2,numero2,saldo2,limite2);
        JOptionPane.showMessageDialog(null, "Saldo da conta 1: "+ c1.getSaldoDisponivel());
        JOptionPane.showMessageDialog(null, "Saldo da conta 2: "+ c2.getSaldoDisponivel());
        do{
       int escolhaConta;
        int escolhaConta = Integer.parseInt(JOptionPane.showInputDialog("Escolha a conta que deseja movimentar.(1 ou 2)\n");
        }while(escolhaConta < 1 && escolhaConta > 2);
        
        int escolha = Integer.parseInt(JOptionPane.showInputDialog("Para Creditar, digite 1.\n"
                + "Para Debitar, digite 2.\n"
                + "Para Transferências, digite 3.\n"));
        do{
        if(escolha == 1){
            
            
        }
        else if(escolha == 2){
            
            
        }
        else if(escolha == 3){
            
        }
        else {
          JOptionPane.showInputDialog("Escolha inválida!");
        }
        //System.out.println(c1.getSaldoDisponivel());
        //System.out.println(c2.getSaldoDisponivel());
    }
